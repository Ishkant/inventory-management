package com.inventory.management;

public class OrderService {

}
