package com.inventory.inventory_management.controller;  // Corrected package name

import com.inventory.inventory_management.entity.Product;
import com.inventory.inventory_management.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://127.0.0.1:5500")  // Allow CORS from your frontend (adjust if different frontend URL)
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    // Add a new product
    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        return productRepository.save(product);  // Save product to the database
    }

    // Get all products
    @GetMapping
    public List<Product> getAllProducts() {
        return productRepository.findAll(); 
    }
}
